package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.audio.AudioNode;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.collision.CollisionResults;
import com.jme3.font.BitmapFont;
import com.jme3.font.BitmapText;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.AnalogListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseAxisTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Quaternion;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Box;
import com.jme3.scene.shape.Sphere;

/**
 * test
 * @author SHUHAO ZHANG    ID: 201138949   x5sz2
 * 
 */
public class Main extends SimpleApplication {
    private BulletAppState bulletAppState;  
    private Spatial poolTable;
    private Spatial cue;
    private Boolean isRunning=true;
    private Geometry whiteBall;
    private Geometry redBall;
    private Geometry centerArea;
    private Node pivotNode =new Node("pivot node");
    private int resultwhite=0;
    private int resultred=0;
    private int time=0;
    private int score=0;
    private int count=5;
    private AudioNode audio_hit;
    private AudioNode audio_background;
    private boolean check = true;
    private BitmapText TextforScore;
    private BitmapText TextforHit;
    private BitmapText TextforName;
    private BitmapText TextforPause;
    public static float PIXELSMOVED_TO_RADIANSROTATED=0.01f;

    public static void main(String[] args) {
        Main app = new Main();
        app.start();
    }

    public Main() {
    
    }

    @Override
    public void simpleInitApp() {
        
        bulletAppState = new BulletAppState();
        stateManager.attach(bulletAppState);
        //set the background color
        viewPort.setBackgroundColor(ColorRGBA.LightGray);
        
        //poolTable
        poolTable = assetManager.loadModel("Models/poolTablenew.j3o");
        poolTable.setLocalScale(1f);
        rootNode.attachChild(poolTable);
        
        //cue
        cue=assetManager.loadModel("Models/CUECUE.j3o");
        cue.setLocalScale(0.1f);
        //cue can rotate according to the center point pivotNode
        pivotNode.attachChild(cue);
        //keep the same distance between pivotNode and cue
        cue.move(-0.3f, 0f, 0f);
        rootNode.attachChild(pivotNode);
        
        //whiteBall
        Material mat = new Material(assetManager,"Common/MatDefs/Light/Lighting.j3md");
        Sphere b = new Sphere(60,60,0.1f);
        whiteBall= new Geometry("Sphere", b);
        whiteBall.setMaterial(mat);
        rootNode.attachChild(whiteBall);
          
        //redBall
        Material matred = new Material(assetManager, "Common/MatDefs/Light/Lighting.j3md");
        Sphere a = new Sphere(60,60,0.1f);
        redBall = new Geometry("Sphere",a);
        matred.setBoolean("UseMaterialColors", true);
        matred.setColor("Diffuse", ColorRGBA.Red);
        redBall.setMaterial(matred);
       
        //centreArea (Red Box)
        Material matarea = new Material(assetManager, "Common/MatDefs/Light/Lighting.j3md");
        Box square = new Box(0.5f,1f,0.5f);
        centerArea= new Geometry("Box",square);
        matarea.setBoolean("UseMaterialColors", true);
        matarea.setColor("Diffuse", ColorRGBA.Red);
        centerArea.setMaterial(matarea);
        rootNode.attachChild(centerArea);
        
        //camera
        cam.setFrustumPerspective(45.0f, (float)settings.getWidth()/(float)settings.getHeight(), 1f, 100f);
        cam.setLocation(new Vector3f(0,8,0));
        cam.lookAt(Vector3f.ZERO, Vector3f.UNIT_Y);
        //make the camera fixed
        flyCam.setEnabled(false);
      
        //RigidBodyControl
        //Table is static
        RigidBodyControl TableControl= new RigidBodyControl(0f);
        poolTable.addControl(TableControl);
        TableControl.setPhysicsLocation(new Vector3f(0f,0f,0f));
        TableControl.setRestitution(0.3f);
        TableControl.setFriction(1.0f);
        TableControl.setDamping(0, 0.1f);
        bulletAppState.getPhysicsSpace().add(TableControl);
        
        //whiteBall
        RigidBodyControl whiteBallControl = new RigidBodyControl(10f);
        whiteBall.addControl(whiteBallControl);
        whiteBallControl.setPhysicsLocation(new Vector3f(-2f,0.1f,0f)); 
        whiteBallControl.setRestitution(1.0f);
        whiteBallControl.setFriction(1f);
        whiteBallControl.setDamping(0, 0.1f); 
        bulletAppState.getPhysicsSpace().add(whiteBallControl);
        
        //redBall
        RigidBodyControl redBallControl = new RigidBodyControl(10f);
        redBall.addControl(redBallControl);
        bulletAppState.getPhysicsSpace().add(redBallControl);
        redBallControl.setPhysicsLocation(new Vector3f(2f,0.1f,0f));
        redBallControl.setRestitution(1.0f);
        redBallControl.setFriction(1f);
        redBallControl.setDamping(0, 0.1f); 
        rootNode.attachChild(redBall);    
        
        //Audio
        //sound for hitting the pool ball
        audio_hit = new AudioNode(assetManager,"Sounds/Billiardhit.wav", false);
        audio_hit.setPositional(false);
        audio_hit.setLooping(false);
        audio_hit.setVolume(2);
        rootNode.attachChild(audio_hit);
        //background music (simulate billiards room)
        audio_background = new AudioNode(assetManager,"Sounds/background.ogg", false);
        audio_background.setPositional(false);
        audio_background.setLooping(false);
        audio_background.setVolume(0.5f);
        rootNode.attachChild(audio_background);
        //play the background music all the time
        audio_background.play();
        
        //light
        DirectionalLight sun = new DirectionalLight();
        sun.setColor(ColorRGBA.White);
        sun.setDirection(new Vector3f(1f,-2.8f,2f).normalizeLocal());
        rootNode.addLight(sun);   
        
        //mouse control 
        initKeys();
       
        //Text
        //Score
        BitmapFont fnt = assetManager.loadFont("Interface/Fonts/Default.fnt");
        TextforScore = new BitmapText(fnt, false);
        TextforScore.setSize(fnt.getPreferredSize() * 2f);
        TextforScore.setText("Score: "+score);
        TextforScore.setLocalTranslation(30, 460, 0);
        guiNode.attachChild(TextforScore);
        //reminder hit
        TextforHit = new BitmapText(fnt, false);
        TextforHit.setSize(fnt.getPreferredSize() * 2f);
        TextforHit.setText("Remain hit: "+count);
        TextforHit.setLocalTranslation(430, 460, 0);
        guiNode.attachChild(TextforHit);
        //game name
        TextforName = new BitmapText(fnt, false);
        TextforName.setSize(fnt.getPreferredSize() * 1.5f);
        TextforName.setText("Billiards Game");
        TextforName.setColor(ColorRGBA.White);
        TextforName.setLocalTranslation(250, 95, 0);
        guiNode.attachChild(TextforName);
        //pause
        TextforPause = new BitmapText(fnt,false);
        TextforPause.setSize(fnt.getPreferredSize() * 1.5f);
        TextforPause.setColor(ColorRGBA.White);
        TextforPause.setLocalTranslation(280,260, 0);
        guiNode.attachChild(TextforPause);
    }
     
   private void initKeys(){
   inputManager.setCursorVisible(true);
   inputManager.addMapping("Hit", new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
   inputManager.addListener(analogListener, "Hit");
   inputManager.addMapping("Pause",  new KeyTrigger(KeyInput.KEY_P));
   inputManager.addListener(actionListener,"Pause");
   inputManager.addMapping("MouseMoved", 
                new MouseAxisTrigger(MouseInput.AXIS_X, false),
                new MouseAxisTrigger(MouseInput.AXIS_X, true));
   inputManager.addListener(analogListener, "MouseMoved");
   }              
    
  private AnalogListener analogListener = new AnalogListener(){
     
    public void onAnalog(String name, float value, float tpf) {
    if(check){  
      if (isRunning) {
          /*
           * the method that using the mouse movement in x Axis to control the cue is from the website
           * i get the idea from this website. 
           * Ref: http://stackoverflow.com/questions/23704138/how-to-listen-for-mouse-movements-correctrly-in-jme3
           */
          if(name.equals("MouseMoved")){
           inputManager.getCursorPosition();
                    float centredX=inputManager.getCursorPosition().x-0.5f*settings.getWidth();
                    Quaternion quat=new Quaternion();
                    quat.fromAngles(0, PIXELSMOVED_TO_RADIANSROTATED*centredX, 0);
                    pivotNode.setLocalRotation(quat);   
          }      
          else if(name.equals("Hit")){ 
           //sound for hit
           audio_hit.playInstance();
           //after one hit, the reminder hit times decrease 1
           count=count-1;
           //give a speed for whiteball 
           whiteBall.getControl(RigidBodyControl.class).setLinearVelocity(pivotNode.getWorldTranslation().subtract(cue.getWorldTranslation()).mult(10)); 
          }  
      }else{
      //if isnotRunning. (system pause)
      System.out.println("Press P to unpause.");
      }
        }else{
        //whiteball hit the centerArea, game over
        pivotNode.detachAllChildren();
        }   
     }
  };
    //for action pause
    private ActionListener actionListener = new ActionListener() {
    public void onAction(String name, boolean keyPressed, float tpf) {
        if (name.equals("Pause") && !keyPressed) {
                if(isRunning){
                 //show the text "pause" on the screen
                TextforPause.setText("Pause");
                }else{
                 //remove the text "pause"
                TextforPause.setText("  ");
                }
        //pause the game
        isRunning = !isRunning;
        }
      }
    };
    
    //using ray to get the collision between whiteBall and centerArea
   private int collisionDetectionwhite(Spatial s){  
            CollisionResults results = new CollisionResults();
            //the direction of ray is the direction of whiteball's movement
            Ray ray= new Ray(pivotNode.getWorldTranslation(),cue.getWorldTranslation());
            centerArea.collideWith(ray, results);
            return results.size();
   }
    //using ray to get the collision between redBall and centerArea
    private int collisionDetectionred(Spatial s){  
            CollisionResults results = new CollisionResults();
            //make the ray that vertical to the pooltable
            Vector3f ball= new Vector3f(s.getWorldTranslation().x,1f,s.getWorldTranslation().z);
            Vector3f bottom= new Vector3f(s.getWorldTranslation().x,-1f,s.getWorldTranslation().z);
            Ray ray= new Ray(ball,bottom);
            centerArea.collideWith(ray, results);
            return results.size();
   }
   
    @Override
    public void simpleUpdate(float tpf) {
            //the pivotNode set the same location with whiteBall
            //so that the cue can follow whiteBall all the time
            pivotNode.setLocalTranslation(whiteBall.getLocalTranslation());
            //get the collision result of whiteBall and redBall
            resultwhite= collisionDetectionwhite(whiteBall);
            resultred  = collisionDetectionred(redBall);
            if(check){
                    //whiteBall hit the centerArea
                    if(resultwhite==1){
                         System.out.println("Game Over");
                         check =!check;
                    //redBall hit the centerArea
                    }else if(resultred==2&&time==0){
                         System.out.println("You Win");
                         //compute the score
                         score = score+100;
                         //rotate
                         centerArea.rotate(0, 10, 0);
                         //when the redBall on the centerArea
                         //score only compute once, and only print out once result
                         time = time+1; 
                    }
            //when redBall leave the centerArea
            //collision will be considered again
            if(resultred==0&&time!=0){
            time=0;
            }    
       }
         //change the value of score and reminder hit;
         TextforScore.setText("Score:"+score); 
         TextforHit.setText("Remain hit: "+count);
    }
    

    @Override
    public void simpleRender(RenderManager rm) {
        //TODO: add render code
    }
    }
 
    

